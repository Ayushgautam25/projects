package com.example.perfection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
