package com.example.perfection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerfectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(PerfectionApplication.class, args);
	}

}
